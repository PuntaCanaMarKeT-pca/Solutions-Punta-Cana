// main.js - simple static app renderer

const DATA_URL = "assets/data/technicians.json";

async function fetchData(){
  if(window.__data) return window.__data;
  const res = await fetch(DATA_URL);
  const data = await res.json();
  window.__data = data;
  return data;
}

// categories rendering
const CATEGORIES = [
  {id:'plomeria', title:'Plomería', icon:'🔧'},
  {id:'electricidad', title:'Electricidad', icon:'⚡'},
  {id:'refrigeracion', title:'Refrigeración', icon:'❄️'},
  {id:'aires', title:'Mantenimiento A/C', icon:'🌬️'},
  {id:'mecanica', title:'Mecánica', icon:'🔩'},
  {id:'pintura', title:'Pintura', icon:'🎨'},
  {id:'cerrajeria', title:'Cerrajería', icon:'🗝️'},
  {id:'herreria', title:'Herrería', icon:'🔨'}
];

function renderCategories(gridId="categoriesGrid"){
  const grid = document.getElementById(gridId);
  if(!grid) return;
  grid.innerHTML = "";
  CATEGORIES.forEach(cat=>{
    const el = document.createElement("button");
    el.className="cat-card";
    el.onclick = ()=>{ location.href = "technicians.html?cat="+cat.id; };
    el.innerHTML = `<div class="cat-icon">${cat.icon}</div><div><strong>${cat.title}</strong><div class="muted">Técnicos disponibles</div></div>`;
    grid.appendChild(el);
  });
}

// featured technicians
async function renderFeatured(){
  const data = await fetchData();
  const featured = data.technicians.slice(0,6);
  const grid = document.getElementById("featuredGrid");
  if(!grid) return;
  grid.innerHTML = "";
  featured.forEach(t=>{
    const card = document.createElement("div");
    card.className = "tech-card";
    card.innerHTML = `<img src="${t.photo}" alt="${t.name}" onerror="this.src='assets/img/icons/user-placeholder.png'"/>
      <div class="meta">
        <strong>${t.name}</strong>
        <div class="muted">${t.services.join(", ")}</div>
        <div class="muted">${t.zone}</div>
      </div>
      <div class="actions">
        <a class="btn" href="technician-profile.html?id=${t.id}">Ver</a>
        <a class="btn" target="_blank" href="https://wa.me/${t.phone.replace(/\\D/g,'')}?text=${encodeURIComponent('Hola '+t.name+' quisiera contratar tu servicio.')}">WhatsApp</a>
      </div>`;
    grid.appendChild(card);
  });
}

async function renderTechnicians(){
  const data = await fetchData();
  const list = document.getElementById("techList");
  if(!list) return;
  const q = (document.getElementById("techSearch")?.value || "").toLowerCase();
  const zone = (document.getElementById("techZoneFilter")?.value || "");
  let techs = data.technicians;
  if(location.search){
    const params = new URLSearchParams(location.search);
    const cat = params.get('cat');
    if(cat) techs = techs.filter(t=> t.servicesIds && t.servicesIds.includes(cat));
  }
  if(q) techs = techs.filter(t=> (t.name+t.services.join(" ")+t.zone).toLowerCase().includes(q));
  if(zone) techs = techs.filter(t=> t.zone===zone);
  list.innerHTML = "";
  if(techs.length===0) list.innerHTML = "<p class='muted'>No se encontraron técnicos.</p>";
  techs.forEach(t=>{
    const card = document.createElement("div");
    card.className = "tech-card";
    card.innerHTML = `<img src="${t.photo}" alt="${t.name}" onerror="this.src='assets/img/icons/user-placeholder.png'"/>
      <div class="meta">
        <strong>${t.name}</strong>
        <div class="muted">${t.services.join(", ")}</div>
        <div class="muted">${t.zone} • ${t.rating} ⭐</div>
      </div>
      <div class="actions">
        <a class="btn" href="technician-profile.html?id=${t.id}">Ver</a>
        <a class="btn" target="_blank" href="https://wa.me/${t.phone.replace(/\\D/g,'')}?text=${encodeURIComponent('Hola '+t.name+' quisiera contratar tu servicio.')}">WhatsApp</a>
      </div>`;
    list.appendChild(card);
  });
}

async function renderProfile(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if(!id) return document.getElementById('profileMain').innerHTML='<p class="muted">ID de técnico no proporcionado.</p>';
  const data = await fetchData();
  const t = data.technicians.find(x=> x.id===id);
  if(!t) return document.getElementById('profileMain').innerHTML='<p class="muted">Técnico no encontrado.</p>';
  const main = document.getElementById('profileMain');
  main.innerHTML = `<div class="profile">
    <div class="profile-top">
      <img src="${t.photo}" alt="${t.name}" onerror="this.src='assets/img/icons/user-placeholder.png'"/>
      <div>
        <h1>${t.name}</h1>
        <p class="muted">${t.zone} • ${t.rating} ⭐</p>
        <p>${t.bio || ''}</p>
        <p><strong>Servicios:</strong> ${t.services.join(", ")}</p>
        <div class="actions">
          <a target="_blank" href="https://wa.me/${t.phone.replace(/\\D/g,'')}?text=${encodeURIComponent('Hola '+t.name+' quisiera contratar tu servicio.')}">Contactar por WhatsApp</a>
          <a href="tel:${t.phone}">Llamar</a>
        </div>
      </div>
    </div>
  </div>`;
}

function submitContact(e){
  e.preventDefault();
  const f = e.target;
  const name = f.name.value;
  const phone = f.phone.value.replace(/\\D/g,'');
  const message = f.message.value;
  const text = encodeURIComponent(`Contacto desde TechTasks: ${name} - ${phone} - ${message}`);
  const wa = "https://wa.me/18091234567?text="+text; // TODO: replace with real number
  window.open(wa,"_blank");
}

function performSearch(){
  const q = document.getElementById('searchInput').value;
  const zone = document.getElementById('zoneFilter').value;
  const params = new URLSearchParams();
  if(q) params.set('q', q);
  if(zone) params.set('zone', zone);
  location.href = "technicians.html?"+params.toString();
}

document.addEventListener('DOMContentLoaded', async ()=>{
  renderCategories("categoriesGrid");
  renderCategories("categoriesGridFull");
  await renderFeatured();
  if(location.pathname.endsWith("technicians.html")) renderTechnicians();
  if(location.pathname.endsWith("technician-profile.html")) renderProfile();
  const params = new URLSearchParams(location.search);
  if(params.get('q')) document.getElementById('techSearch') && (document.getElementById('techSearch').value = params.get('q'));
  if(params.get('zone')) document.getElementById('techZoneFilter') && (document.getElementById('techZoneFilter').value = params.get('zone'));
});
